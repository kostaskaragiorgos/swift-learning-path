
class Spaceship {
    var fuellevel = 100
    
    func cru(){
    print(fuellevel)
    
}
    func thr(){
    print(fuellevel)
}

    func setfuel (_ x:Int)
    {
        fuellevel = x
    }
    
    func getfuel() -> Int {
        return fuellevel
    }
}

var kostas =  Spaceship()
kostas.thr()
kostas.setfuel(5000)
print(kostas.getfuel())


