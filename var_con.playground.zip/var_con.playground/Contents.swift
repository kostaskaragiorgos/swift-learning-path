import UIKit

var str = "Hello, playground"
print(str)
var f = 10
print(f)
print(f+10)
var g = false
print(g)
let pi  = 3.14
print(pi)
var y:Double = 0.1212221
print(y)
