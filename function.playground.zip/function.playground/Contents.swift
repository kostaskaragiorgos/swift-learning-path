import UIKit

func sayH(){
    print("HELLO")
}

sayH()


func hi_to(name:String){
    print("hi \(name)")
}
hi_to(name: "takis")

func add(_ x:Int,_ y:Int) -> Int {
    return x+y
    
}

var c = add(4,5)
print(c)


