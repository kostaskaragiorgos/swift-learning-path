import UIKit

var a = 2

if a > 10 {
    print(a)
}
else
{
    print("10")
}

if a > 10
{
    print("nooooo")
} else if a < 10
{
    print("yes")
}
